
\begingroup
\thispagestyle{empty}
\begin{center}

\hspace{1mm}
\vspace{2cm}

\includegraphics[trim={13.5cm 0 0 0},clip,width=12cm]{static/images/logo_ccssttii_talavera.jpg}

\vspace{2cm}

\Large
UNIVERSIDAD DE CASTILLA-LA MANCHA

\vspace{1cm}

TRABAJO FIN DE GRADO

\vspace{1cm}

GRADO EN INGENIERÍA INFORMÁTICA

\vspace{1.0cm}

\Title

\Subtitle

\Name

\flushright

\vspace*{\fill}

\Month , \Year


\end{center}
\endgroup

\cleardoublepage

