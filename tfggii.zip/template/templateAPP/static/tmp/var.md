\def\Cotutor{Nombre del Co-tutor Académico}
\def\Department{Departamento tutor académico}
\def\Month{Mes}
\def\Name{Nombre}
\def\Technology{Tecnología Específica}
\def\Title{Título (esp)}
\def\Subtitle{Título (eng)}
\def\Tutor{Nombre del Tutor Académico}
\def\Year{Año}
